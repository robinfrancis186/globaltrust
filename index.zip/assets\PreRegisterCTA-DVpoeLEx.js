import{j as n}from"./vendor-animations-C2DMl_DF.js";import{u as I,b as A,r as y}from"./vendor-react-CJ6gRUnz.js";import{L as z,A as P}from"./index-D6B9zcTl.js";function H(){const k=I(),M=A(),j=o=>{if(o.preventDefault(),k.pathname!=="/")M("/?scroll=pre-registration");else{const e=document.getElementById("pre-registration");e==null||e.scrollIntoView({behavior:"smooth"})}},h=y.useRef(null);return y.useEffect(()=>{const o=h.current;if(!o)return;const e=o.getContext("2d");if(!e)return;let r=0,i=0,c=1,g=[],b=0,l;const u=()=>{const a=o.parentElement;if(!a)return;const t=a.getBoundingClientRect();r=t.width,i=t.height,(r===0||i===0)&&(r=a.clientWidth||window.innerWidth,i=a.clientHeight||window.innerHeight),c=Math.min(Math.max(window.devicePixelRatio||1,1),2),o.width=Math.floor(r*c),o.height=Math.floor(i*c),o.style.width=`${r}px`,o.style.height=`${i}px`,e.setTransform(c,0,0,c,0,0);const s=Math.floor(r*i/1200);g=new Array(s).fill(0).map(()=>({x:Math.random()*r,y:Math.random()*i,depth:.25+Math.random()*.75,radius:.4+Math.random()*1.2,twinkle:Math.random()*Math.PI*2,twinkleSpeed:.002+Math.random()*.006}))},C=()=>{const a=e.createLinearGradient(0,0,0,i);a.addColorStop(0,"#0a1a2e"),a.addColorStop(1,"#040815"),e.fillStyle=a,e.fillRect(0,0,r,i)},N=()=>{const a=b*4e-5;e.globalCompositeOperation="lighter";const t=r*(.25+.05*Math.sin(a*6)),s=i*(.35+.04*Math.cos(a*5)),p=Math.max(r,i)*.75,m=e.createRadialGradient(t,s,0,t,s,p);m.addColorStop(0,"rgba(99, 102, 241, 0.22)"),m.addColorStop(1,"transparent"),e.fillStyle=m,e.fillRect(0,0,r,i);const w=r*(.7+.07*Math.cos(a*4)),v=i*(.6+.05*Math.sin(a*3)),S=Math.max(r,i)*.85,f=e.createRadialGradient(w,v,0,w,v,S);f.addColorStop(0,"rgba(59, 197, 255, 0.18)"),f.addColorStop(1,"transparent"),e.fillStyle=f,e.fillRect(0,0,r,i),e.globalCompositeOperation="source-over"},R=a=>{for(const t of g){t.twinkle+=t.twinkleSpeed*a;const s=.75+.25*Math.sin(t.twinkle),p=t.radius*(1+(1-t.depth)*.5)*s;e.fillStyle=`hsla(210, 90%, ${65+15*s}%, ${.55+.25*s})`,e.beginPath(),e.arc(t.x,t.y,p,0,Math.PI*2),e.fill()}};let d=performance.now();const x=a=>{const t=a-d;d=a,b+=t,C(),N(),R(t),l=requestAnimationFrame(x)},_=new ResizeObserver(u);return o.parentElement&&_.observe(o.parentElement),setTimeout(()=>{u(),d=performance.now(),l=requestAnimationFrame(x)},0),()=>{l&&cancelAnimationFrame(l),_.disconnect()}},[]),n.jsxs("div",{className:"idea-cta",children:[n.jsx("canvas",{ref:h,className:"idea-cta-canvas"}),n.jsx("div",{className:"idea-cta-vignette","aria-hidden":"true"}),n.jsxs("div",{className:"max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center idea-cta__content",children:[n.jsxs("div",{className:"idea-cta__iconWrap",children:[n.jsx("span",{className:"idea-cta__iconGlow","aria-hidden":!0}),n.jsx(z,{className:"idea-cta__icon",strokeWidth:1.6})]}),n.jsx("h2",{className:"idea-cta__title",children:"Got an Idea?"}),n.jsx("p",{className:"idea-cta__subtitle",children:"Pre-register now to be among the first to submit your innovative solution"}),n.jsxs("a",{href:"#pre-registration",onClick:j,className:"idea-cta__chip",children:["Pre-register now",n.jsx("span",{className:"idea-cta__chipArrow",children:n.jsx(P,{size:20,strokeWidth:2.4})}),n.jsx("span",{className:"idea-cta__chipHalo","aria-hidden":!0})]})]}),n.jsx("style",{children:`
          .idea-cta {
            position: relative;
            padding: clamp(3rem, 6vw, 5.5rem) 0;
            color: #fff;
            overflow: hidden;
            background: #040815;
          }
          .idea-cta-canvas {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: block;
            pointer-events: none;
            z-index: 0;
          }
          .idea-cta-vignette {
            position: absolute;
            inset: 0;
            pointer-events: none;
            z-index: 1;
            background:
              linear-gradient(180deg, rgba(0,0,0,0.35), transparent 40%),
              radial-gradient(80% 70% at 50% 10%, rgba(0,0,0,0.0), rgba(0,0,0,0.2) 60%, rgba(0,0,0,0.4) 100%);
          }
          .idea-cta__content {
            min-height: clamp(18rem, 36vw, 24rem);
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            z-index: 10;
          }
          .idea-cta__iconWrap {
            position: relative;
            width: 4.1rem;
            height: 4.1rem;
            margin: clamp(0.3rem, 1.4vw, 1.25rem) auto clamp(1.4rem, 2.2vw, 1.8rem);
            display: flex;
            align-items: center;
            justify-content: center;
            isolation: isolate;
          }
          .idea-cta__iconGlow {
            position: absolute;
            inset: -40%;
            border-radius: 50%;
            background:
              radial-gradient(circle at 40% 35%, rgba(136, 197, 255, 0.45) 0%, transparent 72%),
              radial-gradient(circle at 70% 70%, rgba(72, 233, 192, 0.28) 0%, transparent 80%);
            filter: blur(16px);
            animation: ideaIconBloom 5.5s ease-in-out infinite alternate;
            opacity: 0.75;
          }
          .idea-cta__icon {
            position: relative;
            width: 2.5rem;
            height: 2.5rem;
            color: #f6fcff;
            filter:
              drop-shadow(0 10px 20px rgba(17, 24, 39, 0.4))
              drop-shadow(0 0 18px rgba(82, 236, 255, 0.65));
            animation: ideaIconPulse 3s ease-in-out infinite;
          }
          .idea-cta__title {
            margin: 0 0 0.85rem 0;
            font-family: "Barlow Condensed", "Inter", sans-serif;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.2em;
            font-size: clamp(2.45rem, 6.5vw, 3.75rem);
            background: linear-gradient(92deg, #bb6bff 0%, #6f8cff 38%, #3fd7ff 72%, #6affd2 100%);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow:
              0 -2px 8px rgba(255, 255, 255, 0.25),
              0 10px 18px rgba(13, 20, 35, 0.55),
              0 0 35px rgba(90, 239, 255, 0.3);
          }
          .idea-cta__subtitle {
            margin: 0 auto clamp(1.1rem, 2.4vw, 1.8rem);
            max-width: 46rem;
            color: rgba(255,255,255,0.85);
            font-family: "Inter", "Barlow", sans-serif;
            font-size: clamp(1.1rem, 2.2vw, 1.25rem);
            line-height: 1.7;
            letter-spacing: 0.02em;
            text-shadow: 0 6px 18px rgba(10, 20, 35, 0.45);
          }
          .idea-cta__chip {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.95rem 1.9rem;
            border-radius: 999px;
            font-family: "Inter", system-ui, sans-serif;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.16em;
            color: #0b1727;
            background: linear-gradient(120deg, rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.76));
            box-shadow: 0 18px 44px rgba(15, 23, 42, 0.28);
            transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.35s ease, color 0.35s ease;
            isolation: isolate;
          }
          .idea-cta__chip::before {
            content: "";
            position: absolute;
            inset: -1px;
            border-radius: inherit;
            padding: 1px;
            background: linear-gradient(120deg, #8bffe2, #7ed0ff, #b598ff);
            -webkit-mask:
              linear-gradient(#fff 0 0) content-box,
              linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
                    mask-composite: exclude;
            pointer-events: none;
            opacity: 0.95;
          }
          .idea-cta__chip::after {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background: radial-gradient(circle at 50% 0%, rgba(255,255,255,0.4), transparent 65%);
            opacity: 0;
            transition: opacity 0.35s ease;
            pointer-events: none;
          }
          .idea-cta__chipArrow {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.35s ease;
          }
          .idea-cta__chipHalo {
            position: absolute;
            inset: -25%;
            border-radius: inherit;
            background:
              radial-gradient(circle, rgba(255, 255, 255, 0.28) 0%, transparent 45%),
              radial-gradient(circle, rgba(124, 236, 255, 0.45) 0%, transparent 70%);
            filter: blur(12px);
            opacity: 0.55;
            transition: opacity 0.35s ease, transform 0.35s ease;
            z-index: -1;
          }
          .idea-cta__chip:hover,
          .idea-cta__chip:focus-visible {
            transform: translateY(-4px);
            box-shadow: 0 28px 60px rgba(15, 23, 42, 0.32);
            color: #091323;
          }
          .idea-cta__chip:hover::after,
          .idea-cta__chip:focus-visible::after {
            opacity: 1;
          }
          .idea-cta__chip:hover .idea-cta__chipHalo,
          .idea-cta__chip:focus-visible .idea-cta__chipHalo {
            opacity: 0.7;
            transform: scale(1.05);
          }
          .idea-cta__chip:hover .idea-cta__chipArrow,
          .idea-cta__chip:focus-visible .idea-cta__chipArrow {
            transform: translateX(4px);
          }
          @keyframes ideaIconPulse {
            0%, 100% { opacity: 0.7; transform: scale(0.97); }
            50% { opacity: 1; transform: scale(1.04); }
          }
          @keyframes ideaIconBloom {
            0% { transform: scale(0.95); opacity: 0.65; }
            100% { transform: scale(1.05); opacity: 0.85; }
          }
          @media (prefers-reduced-motion: reduce) {
            .idea-cta__icon,
            .idea-cta__iconGlow,
            .idea-cta__chip {
              animation: none !important;
            }
            .idea-cta__chip {
              transition: none;
            }
          }
        `})]})}export{H as default};
