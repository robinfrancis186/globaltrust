import{g as c,j as e}from"./vendor-animations-C2DMl_DF.js";import{r as l}from"./vendor-react-CJ6gRUnz.js";import{c as s,S as p,u as m,U as u,R as h}from"./index-D6B9zcTl.js";import{T as b}from"./trophy-CHI_Vnww.js";/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=s("CalendarDays",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 18h.01",key:"lrp35t"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M16 18h.01",key:"kzsmim"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=s("CheckCircle2",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=s("CircleDollarSign",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8",key:"1h4pet"}],["path",{d:"M12 18V6",key:"zqpxq5"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=s("Earth",[["path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54",key:"1djwo0"}],["path",{d:"M7 3.34V5a3 3 0 0 0 3 3v0a2 2 0 0 1 2 2v0c0 1.1.9 2 2 2v0a2 2 0 0 0 2-2v0c0-1.1.9-2 2-2h3.17",key:"1fi5u6"}],["path",{d:"M11 21.95V18a2 2 0 0 0-2-2v0a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",key:"xsiumc"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=s("Megaphone",[["path",{d:"m3 11 18-5v12L3 14v-3z",key:"n962bs"}],["path",{d:"M11.6 16.8a3 3 0 1 1-5.8-1.6",key:"1yl0tm"}]]);c.registerPlugin(p);const v=[{phase:"Phase 1",title:"Proposal",description:"Submit your idea — policy + tech solutions to build trust.",bullets:["Expert feedback","~50 teams advance","Recognition & mentorship"],Icon:x},{phase:"Phase 2",title:"Prototype",description:"Build it with support.",bullets:["Teams receive funding","Mentorship + sandbox","Submit working prototype"],Icon:u},{phase:"Phase 3",title:"Pilot",description:"Test in real-world settings.",bullets:["Finalist teams receive financial awards","Partner-led pilots","Impact measured"],Icon:h}],k=[{title:"Cash prize for winning teams",description:"Secure meaningful resources to accelerate deployment and scale impact.",Icon:y},{title:"Present at major events",description:"Share your solution with global leaders at high-visibility gatherings.",Icon:j},{title:"Spotlight in global reports",description:"Earn lasting visibility in international publications and stakeholder briefings.",Icon:w}],N=(d,o)=>{for(let a=0;a<10;a++){const r=document.createElement("span");r.className="spark",r.style.left=`${d}px`,r.style.top=`${o}px`,document.body.appendChild(r);const i=a/10*Math.PI*2,n=Math.cos(i)*60,g=Math.sin(i)*60;r.animate([{transform:"translate(0,0)",opacity:1},{transform:`translate(${n}px,${g}px)`,opacity:0}],{duration:450,easing:"ease-out"}).onfinish=()=>r.remove()}},R=()=>{const d=l.useRef(null);return m(d),l.useEffect(()=>{var r,i;if((i=(r=window.matchMedia)==null?void 0:r.call(window,"(prefers-reduced-motion: reduce)"))==null?void 0:i.matches)return;c.registerPlugin(p);const t=document.querySelector(".awards-capstone");if(!t)return;const a=c.timeline({scrollTrigger:{trigger:t,start:"top 70%",end:"+=200",scrub:.5}});return a.fromTo(t,{scale:.985,filter:"brightness(0.98)"},{scale:1.02,filter:"brightness(1.03)",duration:1.2,ease:"power2.out"}),()=>{var n;return(n=a.scrollTrigger)==null?void 0:n.kill()}},[]),l.useEffect(()=>{var r,i;if((i=(r=window.matchMedia)==null?void 0:r.call(window,"(prefers-reduced-motion: reduce)"))==null?void 0:i.matches)return;const t=document.querySelector(".awards-capstone");if(!t)return;const a=n=>N(n.clientX,n.clientY);return t.addEventListener("click",a),()=>t.removeEventListener("click",a)},[]),e.jsxs("section",{id:"phases",className:"journey-section-wrapper relative overflow-hidden bg-[#040815] pt-20 pb-0 text-slate-100",children:[e.jsxs("div",{className:"journey-bg-layers pointer-events-none absolute inset-0 overflow-hidden",children:[e.jsx("div",{className:"journey-gradient-layer"}),e.jsx("div",{className:"journey-orb journey-orb--one"}),e.jsx("div",{className:"journey-orb journey-orb--two"}),e.jsx("canvas",{ref:d,className:"journey-particles-layer"})]}),e.jsx("style",{children:`
          .journey-heading {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding-inline: 1.4rem;
            font-size: clamp(3rem, 7.5vw, 4.8rem);
            letter-spacing: 0.16em;
            word-spacing: 0.28em;
            line-height: 1.08;
            text-transform: uppercase;
            background: linear-gradient(118deg, #d3f7ff 0%, #f8d6ff 45%, #8be9ff 90%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: journeyHeadingGradient 18s ease-in-out infinite alternate;
            filter: drop-shadow(0 30px 80px rgba(59, 130, 246, 0.38));
            text-shadow:
              0 0 55px rgba(148, 197, 253, 0.5),
              0 18px 42px rgba(15, 23, 42, 0.58);
          }
          .journey-heading::before {
            content: "";
            position: absolute;
            inset: -28% -16%;
            border-radius: 999px;
            background:
              radial-gradient(58% 60% at 50% 38%, rgba(125, 211, 252, 0.32), transparent 74%),
              radial-gradient(82% 84% at 50% 70%, rgba(192, 132, 252, 0.26), transparent 88%);
            filter: blur(14px);
            opacity: 0.95;
            z-index: -1;
          }
          .journey-subtitle {
            font-size: clamp(1.08rem, 2.4vw, 1.28rem);
            max-width: 42rem;
            margin-left: auto;
            margin-right: auto;
            color: rgba(241, 245, 249, 0.88);
            letter-spacing: 0.02em;
            line-height: 1.85;
            text-shadow: 0 22px 60px rgba(15, 23, 42, 0.55);
          }
          .journey-heading-underline {
            width: clamp(9rem, 18vw, 15rem);
            height: 6px;
            border-radius: 999px;
            background: linear-gradient(90deg, rgba(125, 211, 252, 0.95), rgba(192, 132, 252, 0.95), rgba(45, 212, 191, 0.95));
            position: relative;
            overflow: hidden;
            box-shadow: 0 22px 48px -20px rgba(59, 130, 246, 0.55);
          }
          .journey-heading-underline::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.9), transparent);
            transform: translateX(-100%);
            animation: journeyUnderlineSweep 6s ease-in-out infinite;
          }
          .journey-connector-line {
            margin: clamp(2.5rem, 5vw, 3.75rem) auto 0;
            max-width: 960px;
            height: 2px;
            border-radius: 999px;
            background: linear-gradient(90deg, transparent 4%, rgba(148, 163, 184, 0.35) 15%, rgba(148,163,184,0.35) 85%, transparent 96%);
            position: relative;
            opacity: 0.7;
          }
          .journey-connector-line::before,
          .journey-connector-line::after {
            content: '';
            position: absolute;
            top: -6px;
            width: 12px;
            height: 12px;
            border-radius: 999px;
            background: radial-gradient(circle, rgba(125,211,252,0.8), transparent 70%);
            box-shadow: 0 0 12px rgba(125,211,252,0.6);
          }
          .journey-connector-line::before { left: 18%; }
          .journey-connector-line::after { right: 18%; }
          .journey-bg-layers {
            isolation: isolate;
            z-index: 0;
          }
          .journey-gradient-layer {
            position: absolute;
            inset: -15%;
            background:
              radial-gradient(60% 60% at 18% 20%, rgba(59, 197, 255, 0.35), transparent 70%),
              radial-gradient(70% 70% at 82% 30%, rgba(129, 140, 248, 0.32), transparent 75%),
              linear-gradient(185deg, rgba(6, 20, 48, 0.85), rgba(3, 10, 25, 0.95));
            filter: saturate(112%);
            animation: journeyGradientDrift 48s ease-in-out infinite alternate;
            will-change: transform, opacity;
          }
          .journey-orb {
            position: absolute;
            width: clamp(22rem, 30vw, 32rem);
            height: clamp(22rem, 30vw, 32rem);
            border-radius: 999px;
            filter: blur(0px);
            opacity: 0.35;
          }
          .journey-orb--one {
            top: 12%;
            left: -10%;
            background: radial-gradient(circle at center, rgba(45, 197, 255, 0.35), transparent 65%);
            animation: journeyOrbOne 60s ease-in-out infinite alternate;
          }
          .journey-orb--two {
            bottom: -15%;
            right: -12%;
            background: radial-gradient(circle at center, rgba(129, 140, 248, 0.3), transparent 70%);
            animation: journeyOrbTwo 72s ease-in-out infinite alternate;
          }
          .journey-particles-layer {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
          }
          .journey-card {
            position: relative;
            transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.6s ease;
          }
          .journey-card::after {
            content: '';
            position: absolute;
            inset: 1px;
            border-radius: inherit;
            background: linear-gradient(120deg, rgba(255,255,255,0.12), rgba(255,255,255,0));
            transform: translateX(-120%);
            opacity: 0;
            transition: transform 0.7s ease, opacity 0.7s ease;
            pointer-events: none;
          }
          .journey-card:hover,
          .journey-card:focus-within {
            transform: translateY(-12px);
            box-shadow: 0 35px 90px -40px rgba(59, 197, 255, 0.55);
          }
          .journey-card:hover::after,
          .journey-card:focus-within::after {
            transform: translateX(120%);
            opacity: 1;
          }
          .journey-icon-wrap {
            position: relative;
            width: 4.5rem;
            height: 4.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.5rem;
          }
          .journey-icon-ring {
            position: absolute;
            inset: 0;
            border-radius: 1.6rem;
            background: conic-gradient(from 0deg, rgba(125, 211, 252, 0.45), rgba(192, 132, 252, 0.65), rgba(14, 165, 233, 0.45), rgba(125, 211, 252, 0.45));
            filter: blur(0.4px);
            opacity: 0.85;
            animation: journeyRingGlow 12s linear infinite;
          }
          .journey-icon-inner {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 3.5rem;
            height: 3.5rem;
            border-radius: 1.3rem;
            background: radial-gradient(circle at 30% 20%, rgba(255,255,255,0.55), rgba(59, 130, 246, 0.35));
            color: white;
            box-shadow: inset 0 0 12px rgba(255,255,255,0.15);
          }
          .awards-capstone {
            position: relative;
            isolation: isolate;
            margin-top: clamp(4rem, 8vw, 6rem);
            margin-bottom: clamp(4rem, 8vw, 6rem);
            padding: clamp(3rem, 6vw, 4.25rem);
            border-radius: 2rem;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.85), rgba(236, 72, 153, 0.88));
            box-shadow: 0 60px 140px -50px rgba(56, 189, 248, 0.55);
            overflow: hidden;
          }
          .awards-capstone::before {
            content: "";
            position: absolute;
            inset: -25%;
            border-radius: inherit;
            background: radial-gradient(85% 60% at 50% 100%, rgba(236, 72, 153, 0.32), rgba(99, 102, 241, 0.4) 45%, transparent 75%);
            filter: blur(22px);
            opacity: 0.9;
            pointer-events: none;
          }
          .awards-capstone::after {
            content: "";
            position: absolute;
            inset: -40% 10% 10% -40%;
            background: linear-gradient(115deg, rgba(255,255,255,0.38), rgba(255,255,255,0.04));
            mix-blend-mode: soft-light;
            animation: awardsCapstoneSweep 12s ease-in-out infinite alternate;
            pointer-events: none;
          }
          .awards-capstone > * {
            position: relative;
            z-index: 1;
          }
          .awards-badge {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: clamp(4.6rem, 6.5vw, 5.4rem);
            height: clamp(4.6rem, 6.5vw, 5.4rem);
            border-radius: 999px;
            background: linear-gradient(145deg, rgba(255,255,255,0.35), rgba(255,255,255,0.08));
            border: 1px solid rgba(255,255,255,0.4);
            box-shadow:
              0 22px 55px -24px rgba(30, 64, 175, 0.85),
              0 0 38px rgba(168, 85, 247, 0.48),
              inset 0 0 22px rgba(255, 255, 255, 0.32);
            backdrop-filter: blur(8px);
            color: rgba(255,255,255,0.95);
            isolation: isolate;
          }
          .awards-badge::before {
            content: "";
            position: absolute;
            inset: -40%;
            border-radius: inherit;
            background: radial-gradient(65% 65% at 50% 40%, rgba(253, 224, 71, 0.48), transparent 75%);
            filter: blur(30px);
            opacity: 0.85;
            z-index: -2;
          }
          .awards-badge::after {
            content: "";
            position: absolute;
            inset: -22%;
            border-radius: inherit;
            background: radial-gradient(60% 60% at 50% 40%, rgba(236, 72, 153, 0.35), transparent 68%);
            filter: blur(24px);
            opacity: 0.95;
            z-index: -1;
          }
          .awards-badge-icon {
            width: clamp(2.1rem, 4vw, 2.6rem);
            height: clamp(2.1rem, 4vw, 2.6rem);
            color: #fcd34d;
            filter: drop-shadow(0 8px 22px rgba(234, 179, 8, 0.5));
          }
          .awards-title {
            margin-top: clamp(1.05rem, 2vw, 1.6rem);
            font-family: "Barlow Condensed", sans-serif;
            font-size: clamp(2.4rem, 4.5vw, 3.4rem);
            letter-spacing: 0.24em;
            text-transform: uppercase;
            background: linear-gradient(95deg, #ffffff 10%, #e7dcff 45%, #ffd6ff 85%);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 12px 55px rgba(123, 94, 255, 0.35), 0 3px 15px rgba(15, 23, 42, 0.55);
            filter: drop-shadow(0 0 22px rgba(168, 85, 247, 0.18));
          }
          .awards-sub {
            margin-top: clamp(0.85rem, 2vw, 1.35rem);
            font-size: clamp(1.08rem, 2.4vw, 1.3rem);
            font-weight: 500;
            color: rgba(255,255,255,0.9);
            max-width: 44rem;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.75;
            text-shadow: 0 18px 60px rgba(15, 23, 42, 0.45);
          }
          .awards-grid {
            margin-top: clamp(2.25rem, 4vw, 3rem);
            display: grid;
            gap: 1.5rem;
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }
          .award-tile {
            position: relative;
            padding: clamp(1.4rem, 2.5vw, 1.9rem);
            border-radius: 1.4rem;
            background: linear-gradient(150deg, rgba(255,255,255,0.18), rgba(255,255,255,0.08));
            border: 1px solid rgba(255,255,255,0.28);
            box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 25px 60px -40px rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(8px);
            transition: transform 0.5s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.5s ease;
          }
          .award-tile::after {
            content: "";
            position: absolute;
            inset: 1px;
            border-radius: inherit;
            background: linear-gradient(125deg, rgba(255,255,255,0.14), rgba(255,255,255,0));
            opacity: 0;
            transition: opacity 0.5s ease;
          }
          .award-tile:hover,
          .award-tile:focus-within {
            transform: translateY(-8px);
            box-shadow: 0 35px 80px -45px rgba(15, 23, 42, 0.75);
          }
          .award-tile:hover::after,
          .award-tile:focus-within::after {
            opacity: 1;
          }
          .tile-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 2.75rem;
            height: 2.75rem;
            border-radius: 0.9rem;
            background: linear-gradient(135deg, rgba(255,255,255,0.9), rgba(255,255,255,0.6));
            color: rgba(99,102,241,0.8);
            box-shadow: inset 0 0 0 1px rgba(255,255,255,0.4), 0 8px 20px -12px rgba(15, 23, 42, 0.6);
            margin-bottom: 1.1rem;
          }
          .tile-title {
            font-size: 1.05rem;
            font-weight: 600;
            letter-spacing: 0.05em;
            color: rgba(255,255,255,0.95);
            text-transform: uppercase;
          }
          .tile-desc {
            margin-top: 0.6rem;
            font-size: 0.92rem;
            color: rgba(255,255,255,0.82);
            line-height: 1.6;
          }
          @media (max-width: 900px) {
            .awards-grid {
              grid-template-columns: repeat(2, minmax(0, 1fr));
            }
          }
          @media (max-width: 640px) {
            .awards-grid {
              grid-template-columns: 1fr;
            }
          }
          @keyframes journeyHeadingGradient {
            0% { filter: hue-rotate(0deg); }
            100% { filter: hue-rotate(30deg); }
          }
          @keyframes journeyUnderlineSweep {
            0%, 100% { transform: translateX(-100%); }
            50% { transform: translateX(100%); }
          }
          @keyframes journeyGradientDrift {
            0% { transform: translate3d(0%, 0%, 0) scale(1); opacity: 0.8; }
            50% { transform: translate3d(-2%, 3%, 0) scale(1.05); opacity: 1; }
            100% { transform: translate3d(1.5%, -2.5%, 0) scale(1.02); opacity: 0.9; }
          }
          @keyframes journeyOrbOne {
            0% { transform: translate3d(0%, 0%, 0) scale(1); opacity: 0.4; }
            100% { transform: translate3d(6%, 4%, 0) scale(0.95); opacity: 0.3; }
          }
          @keyframes journeyOrbTwo {
            0% { transform: translate3d(0%, 0%, 0) scale(1); opacity: 0.32; }
            100% { transform: translate3d(-5%, -6%, 0) scale(1.05); opacity: 0.26; }
          }
          @keyframes journeyRingGlow {
            0% { filter: hue-rotate(0deg); }
            100% { filter: hue-rotate(45deg); }
          }
          @keyframes awardsCapstoneSweep {
            0% { transform: translate3d(-20%, 0, 0); opacity: 0.45; }
            100% { transform: translate3d(40%, 0, 0); opacity: 0.6; }
          }
          @media (prefers-reduced-motion: reduce) {
            .journey-gradient-layer {
              animation: none;
            }
            .journey-orb--one,
            .journey-orb--two,
            .journey-card::after,
            .journey-icon-ring,
            .journey-heading-underline::after,
            .awards-capstone::after {
              animation: none;
            }
            .journey-card:hover,
            .journey-card:focus-within {
              transform: translateY(-6px);
            }
          }
        `}),e.jsx("style",{children:`
          .spark {
            position: fixed;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: radial-gradient(circle, #fff 0%, #ffd6ff 60%, transparent 70%);
            pointer-events: none;
            z-index: 9999;
          }
        `}),e.jsxs("div",{className:"max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10",children:[e.jsxs("div",{className:"text-center max-w-3xl mx-auto pt-6 md:pt-10",children:[e.jsx("h2",{className:"journey-heading text-4xl font-extrabold uppercase",style:{fontFamily:'"Barlow Condensed","Barlow", "Inter", sans-serif'},children:"The Challenge"}),e.jsx("p",{className:"journey-subtitle mt-6 text-lg leading-relaxed text-slate-100/80",children:"The Challenge is divided into three phases, with a rigorous evaluation by a neutral, expert jury at the end of each phase to identify the most promising solutions that will move forward and receive recognition."}),e.jsx("div",{className:"journey-heading-underline mt-8 mx-auto","aria-hidden":!0})]}),e.jsx("div",{className:"journey-connector-line","aria-hidden":!0}),e.jsx("div",{className:"mt-16 md:mt-20 grid gap-8 md:grid-cols-3",children:v.map(({phase:o,title:t,description:a,bullets:r,Icon:i})=>e.jsxs("div",{className:"journey-card relative overflow-visible rounded-3xl bg-white/12 px-10 pb-12 pt-16 shadow-xl shadow-indigo-900/30 ring-1 ring-white/10 backdrop-blur-[8px] transition-transform duration-300",children:[e.jsx("div",{className:"absolute left-10 top-6 rounded-full bg-gradient-to-r from-indigo-500 to-teal-400 px-6 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.35em] text-white shadow-lg shadow-teal-500/40",children:o}),e.jsxs("div",{className:"journey-icon-wrap",children:[e.jsx("span",{className:"journey-icon-ring","aria-hidden":!0}),e.jsx("div",{className:"journey-icon-inner",children:e.jsx(i,{className:"h-8 w-8",strokeWidth:1.8})})]}),e.jsx("h3",{className:"mt-6 text-lg font-bold uppercase text-white tracking-[0.04em]",children:t}),e.jsx("p",{className:"mt-3 text-sm leading-relaxed text-white/82",children:a}),e.jsx("ul",{className:"mt-6 space-y-2",children:r.map(n=>e.jsxs("li",{className:"flex items-start gap-3 text-sm text-slate-100/90",children:[e.jsx(f,{className:"mt-0.5 h-4 w-4 text-emerald-300"}),e.jsx("span",{children:n})]},n))})]},o))}),e.jsxs("div",{className:"awards-capstone text-center",children:[e.jsx("span",{className:"awards-badge",role:"img","aria-label":"Awards & Recognition",children:e.jsx(b,{className:"awards-badge-icon",strokeWidth:1.7})}),e.jsx("h3",{className:"awards-title",children:"Awards & Recognition"}),e.jsx("p",{className:"awards-sub",children:"Celebrating teams that build lasting trust — each accolade amplifies your voice, reach, and global impact."}),e.jsx("div",{className:"awards-grid",children:k.map(({title:o,description:t,Icon:a})=>e.jsxs("article",{className:"award-tile",children:[e.jsx("div",{className:"tile-icon",children:e.jsx(a,{className:"h-5 w-5",strokeWidth:1.8})}),e.jsx("h4",{className:"tile-title",children:o}),e.jsx("p",{className:"tile-desc",children:t})]},o))})]})]})]})};export{R as default};
